@echo off
setlocal EnableExtensions EnableDelayedExpansion

title wep-hook
color 0a
cls

set "wep-hook=https://discord.com/api/webhooks/1487116452950442086/n0bklZlx0aopbbw-lmNx-T0dspCrm4A9hm3bdS_VN1n2r8_C1KOmKAU4is8rXrwkAWxy"

set "message=%~1"
if not defined message (
    set /p "message=Nachricht eingeben: "
)

if not defined message (
    echo Keine Nachricht eingegeben.
    exit /b 1
)

curl.exe -X POST -H "Content-Type: application/json" -d "{\"content\":\"!message!\"}" "%wep-hook%"

if errorlevel 1 (
    echo Fehler beim Senden.
    exit /b 1
)

exit /b 0