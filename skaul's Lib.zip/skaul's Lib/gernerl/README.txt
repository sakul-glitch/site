this is a multifunctional tutorial guide.
It covers various topics including:

1.get a backup of your 'save file'
(1/2. or you can go fu## yourself and run the backup script i made!)

2.debug (but you can Report it in my githup)

3. or you came from the "helper" tool in the lib.
3/2 and came here for help,
